package com.pennant.cricdb.crud.passwordchange;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class ForgetPassword
 */
@WebServlet("/ForgetPassword")
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static long mobile =0;
   Connection con=null;
	public void init(ServletConfig config) throws ServletException {
	con=DBConnection.getConnectToDb();	
	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	try {
		Statement createStatement = con.createStatement();
		 mobile = Long.parseLong(request.getParameter("mobile"));
		String userName = request.getParameter("username");
		ResultSet executeQuery = createStatement.executeQuery("select username,mobilenumber from cricdb where mobilenumber="+mobile);
		if(executeQuery.next() && userName.equals(executeQuery.getString(1))){
			response.sendRedirect("newpassword.html");
		}
		else{
			response.sendRedirect("forgetPassword.html");
		}
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	}

}
