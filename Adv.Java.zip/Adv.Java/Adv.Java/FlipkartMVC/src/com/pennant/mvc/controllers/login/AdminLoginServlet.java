package com.pennant.mvc.controllers.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.mvc.bean.Admin;
import com.pennant.mvc.dao.admin.AdminOperationsDao;
import com.pennant.mvc.dao.admin.AdminOperationsDaoImpl;


@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();

			String userName = request.getParameter("username");
			String password = request.getParameter("pwd");
			Admin admin=new Admin(userName, password);
			AdminOperationsDao user=new AdminOperationsDaoImpl();
			if(user.checkAdminDetails(admin)){
				session.setAttribute("AdminName", userName);
				response.sendRedirect("insertingproducts.jsp");
			}else{
				response.sendRedirect("adminlogin.jsp");
			}
			
			
	}

}
