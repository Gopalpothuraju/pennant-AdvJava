package com.pennant.mvc.dao.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.pennant.mvc.bean.Admin;
import com.pennant.mvc.bean.FlipkartCategory;
import com.pennant.mvc.bean.FlipkartProducts;
import com.pennant.mvc.factory.DBConnection;

public class AdminOperationsDaoImpl implements AdminOperationsDao{
	Connection con=null;
	public AdminOperationsDaoImpl() {
		con=DBConnection.getConnectToDb();
	}
	@Override
	public boolean checkAdminDetails(Admin admin) {
		boolean execute=false;
		String sql="select * from admin where USERNAME=? and PASSWORD=?";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, admin.getUsername());
			pst.setString(2, admin.getPassword());
			 execute = pst.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return execute;
	}

	@Override
	public int insertAdmin(Admin admin) {
		
		return 0;
	}
	@Override
	public boolean insertingProducts(FlipkartProducts product){
		boolean execute =false;
		try {
			PreparedStatement pst = con.prepareStatement("insert into FLIPKART_PRODUCTS values(PRODUCT_ID_FLIPKARY.nextval,?,?,?,?,?)");
			pst.setString(1, product.getProductName());
			pst.setInt(2, product.getCategoryId());
			pst.setDouble(3,product.getProductPrice());
			pst.setString(4, product.getProductBrand());
			pst.setBinaryStream(5, product.getImage().getInputStream(), (int)  product.getImage().getSize());
			 execute = pst.execute();
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		return execute;
	}
	@Override
	public int retreiveCategoryId(FlipkartCategory categoryName) {
		int categoryId=0;
		try {
			PreparedStatement pst = con.prepareStatement("select * from FLIPKART_CATAGORY where CATEGORY_NAME=?");
			pst.setString(1, categoryName.getCategoryName());
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
			categoryId=rs.getInt(1);}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return categoryId;
	}

}
