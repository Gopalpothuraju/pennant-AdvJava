package com.pennant.cricdb.signup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class VerificationPage
 */
@WebServlet("/VerificationPage")
public class VerificationPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}


	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("username");
		try {
			Statement createStatement = con.createStatement();
		int execute = createStatement.executeUpdate("select username from cricdb where username='"+name+"'");
		System.out.println(execute);
			if(execute>0){
				response.sendRedirect("signup.html");
			}else{
				response.sendRedirect("index.html");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
