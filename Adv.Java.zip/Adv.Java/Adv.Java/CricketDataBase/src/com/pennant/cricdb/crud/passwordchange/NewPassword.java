package com.pennant.cricdb.crud.passwordchange;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;


@WebServlet("/NewPassword")
public class NewPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
  Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}


	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String pwd = request.getParameter("pwd");
	String cnpwd = request.getParameter("cnpwd");
	long mobilenumber=ForgetPassword.mobile;
	PrintWriter pw=response.getWriter();
	if(pwd.equals(cnpwd)){
		try {
			Statement statement = con.createStatement();
			int i = statement.executeUpdate("update cricdb set password='"+pwd+"' where mobilenumber="+mobilenumber);
			if(i>0){
				pw.print("<h2>Password Changed</h2>");
				response.sendRedirect("login.html");
			}else{
				pw.println("<h2>There is an error</h2>");
				response.sendRedirect("forgetPassword.html");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}

}
