package com.pennant.mvc.bean;

import javax.servlet.http.Part;

public class FlipkartProducts {
	
	private int productId;
	private String productName;
	private int categoryId;
	private double productPrice;
	private String productBrand;
	private Part image;
	
	
	public FlipkartProducts(){
		
	}
	public FlipkartProducts(String productName, int categoryId, double productPrice, String productBrand,
			Part image) {
		super();
		this.productName = productName;
		this.categoryId = categoryId;
		this.productPrice = productPrice;
		this.productBrand = productBrand;
		this.image = image;
	}
	public FlipkartProducts(int productId, String productName, int categoryId, double productPrice, String productBrand,
			Part image) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.categoryId = categoryId;
		this.productPrice = productPrice;
		this.productBrand = productBrand;
		this.image = image;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductBrand() {
		return productBrand;
	}
	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}
	public Part getImage() {
		return image;
	}
	public void setImage(Part image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "FlipkartProducts [productId=" + productId + ", productName=" + productName + ", categoryId="
				+ categoryId + ", productPrice=" + productPrice + ", productBrand=" + productBrand + ", image=" + image
				+ "]";
	}
	
	
	}
