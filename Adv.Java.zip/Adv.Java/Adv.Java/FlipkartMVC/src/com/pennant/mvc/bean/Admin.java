package com.pennant.mvc.bean;

public class Admin {
private String username;
private String password;
private double number;


public Admin() {
	super();
}
public Admin(String username, String password) {
	super();
	this.username = username;
	this.password = password;
}
public Admin(String username, String password, double number) {
	super();
	this.username = username;
	this.password = password;
	this.number = number;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public double getNumber() {
	return number;
}
public void setNumber(double number) {
	this.number = number;
}
@Override
public String toString() {
	return "Admin [username=" + username + ", password=" + password + ", number=" + number + "]";
}

}
