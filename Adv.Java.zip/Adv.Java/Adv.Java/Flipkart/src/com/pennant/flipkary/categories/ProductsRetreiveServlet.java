package com.pennant.flipkary.categories;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.flipkary.connection.DBConnection;

@WebServlet("/ProductsRetreiveServlet")
public class ProductsRetreiveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;

	public void init(ServletConfig config) throws ServletException {
		con = DBConnection.getConnectToDb();
	
	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String productType = request.getParameter("name");
		
		try {
			PreparedStatement pst = con
					.prepareStatement("select CATEGORY_ID from FLIPKART_CATAGORY where CATEGORY_NAME=?");
			pst.setString(1, productType);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				Statement st = con.createStatement();
				ResultSet rst = st.executeQuery("select * from flipkart_products where CATEGORY_ID=" + rs.getInt(1));
				
					request.setAttribute("products", rst);
				
					request.getRequestDispatcher("displayProducts.jsp?productType="+productType).include(request, response);
				
				}
			
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

}
