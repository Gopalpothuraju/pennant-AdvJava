package com.pennant.mvc.dao.customer;

import com.pennant.mvc.bean.FlipkartCustomers;

public interface CustomerOperationsDao {
public abstract int customerSignUp(FlipkartCustomers customer);
public abstract boolean customerLogin(FlipkartCustomers customer);
}
