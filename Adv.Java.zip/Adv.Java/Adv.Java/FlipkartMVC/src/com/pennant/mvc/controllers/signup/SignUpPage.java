package com.pennant.mvc.controllers.signup;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.mvc.bean.FlipkartCustomers;
import com.pennant.mvc.dao.customer.CustomerOperationsDao;
import com.pennant.mvc.dao.customer.CustomerOperationsDaoImpl;



@WebServlet("/SignUpPage")
public class SignUpPage extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String email = request.getParameter("email");
		long mobile = Long.parseLong(request.getParameter("number"));
		String password = request.getParameter("pwd");
		HttpSession session=request.getSession();
		String userName=firstName+lastName.charAt(0);
		
		FlipkartCustomers customer=new FlipkartCustomers(userName, password, email, mobile);
		CustomerOperationsDao cust=new CustomerOperationsDaoImpl();
		int i = cust.customerSignUp(customer);
		if(i>0){
			session.setAttribute("userName", userName);
			response.sendRedirect("home.jsp");
		}else{
			response.sendRedirect("signup.jsp");
		}
		
	}

}
