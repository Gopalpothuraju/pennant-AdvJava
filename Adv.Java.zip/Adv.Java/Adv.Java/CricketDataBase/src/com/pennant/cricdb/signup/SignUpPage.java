package com.pennant.cricdb.signup;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class SignUpPage
 */
@WebServlet("/SignUpPage")
public class SignUpPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	
	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String email = request.getParameter("email");
		long mobile = Long.parseLong(request.getParameter("number"));
		String password = request.getParameter("pwd");
		String dateOfJoin = request.getParameter("doj");
		double salary = Double.parseDouble(request.getParameter("salary"));
		
		String userName=firstName+lastName.charAt(0);
		
		try {
			PreparedStatement statement = con.prepareStatement("insert into cricdb values(?,?,?,?,?,?)");
			statement.setString(1,userName);
			statement.setString(2, password);
			statement.setString(3, email);
			statement.setDate(4, Date.valueOf(dateOfJoin));
			statement.setDouble(5, salary);
			statement.setLong(6, mobile);
			int i = statement.executeUpdate();
			if(i>0){
				response.sendRedirect("login.html");
			}else{
				response.sendRedirect("verification.html");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
