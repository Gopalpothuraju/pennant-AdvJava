package com.pennant.flipkary.insertproducts;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.flipkary.connection.DBConnection;

/**
 * Servlet implementation class InsertProducts
 */
@WebServlet("/InsertProducts")
@MultipartConfig
public class InsertProducts extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
   	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	
	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8");
		String productName = request.getParameter("productName");
		String productType = request.getParameter("productType");
		double price=Double.parseDouble(request.getParameter("productPrice"));
		String productBrand = request.getParameter("productBrand");
		Part photo = request.getPart("productImage");
		String sql="insert into flipkart_products values(product_id_flipkary.nextval,?,?,?,?,?)";
		PrintWriter out=response.getWriter();
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, productName);
			PreparedStatement	pst1=con.prepareStatement("select CATEGORY_ID from flipkart_catagory where CATEGORY_NAME='"+productType+"'");
			ResultSet rs = pst1.executeQuery();
			rs.next();
			pst.setInt(2,rs.getInt(1));
			pst.setDouble(3, price);
			pst.setString(4, productBrand);
			pst.setBinaryStream(5, photo.getInputStream(), (int)  photo.getSize());
			int i = pst.executeUpdate();
		
			if(i>0){
				out.println("<center>"+productName+"sucessfully inserted</center>");
				request.getRequestDispatcher("insertingproducts.jsp").include(request, response);
			}
			else{
				out.println("<center>"+productName+"not inserted</center>");
				request.getRequestDispatcher("insertingproducts.jsp").include(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
