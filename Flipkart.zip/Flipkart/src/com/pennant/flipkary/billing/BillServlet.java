package com.pennant.flipkary.billing;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pennant.flipkary.connection.DBConnection;

/**
 * Servlet implementation class BillServlet
 */
@WebServlet("/BillServlet")
public class BillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	Connection con = null;

	public void init(ServletConfig config) throws ServletException {
		con = DBConnection.getConnectToDb();

	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		int count = Integer.parseInt(request.getParameter("count"));
		Enumeration<String> names = session.getAttributeNames();
		String[] products = new String[100];
		int temp = 0;
		if (count > 0) {
			while (names.hasMoreElements()) {
				String string = (String) names.nextElement();
				String value = (String) session.getAttribute(string);
				products[temp] = value;
				temp++;

			}
			java.sql.Statement st;
			String userName = (String) session.getAttribute("userName");
			try {
				st = con.createStatement();

				ResultSet cust_Details = st
						.executeQuery("select * from FLIPKART_CUSTOMERS where USERNAME='" + userName + "'");
				if (cust_Details.next()) {
					for (int i = 0; i < temp; i++) {

						if (userName.equals(products[i])) {

						} else {

							PreparedStatement pst = con.prepareStatement("insert into FLIPKART_BILLING values(?,?)");
							pst.setInt(1, cust_Details.getInt(1));
							pst.setInt(2, Integer.parseInt(products[i]));
							pst.executeUpdate();
						}
					}

					pw.println("Your Order is placed");
					pw.println("<a href='ClearServlet'>click here</a>");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
		response.sendRedirect("emptyBag.jsp");

		}
	}

}