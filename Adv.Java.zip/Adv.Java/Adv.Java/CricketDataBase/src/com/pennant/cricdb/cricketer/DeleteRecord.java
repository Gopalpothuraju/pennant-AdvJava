package com.pennant.cricdb.cricketer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class DeleteRecord
 */
@WebServlet("/DeleteRecord")
public class DeleteRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;
       Connection con=null;
   
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	public void destroy() {
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("playerName");
		int executeUpdate=0;
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from cricketer where name='"+name+"'");
			if(resultSet.next()){
			 executeUpdate = statement.executeUpdate("delete * from cricketer where name='"+name+"'");
			response.sendRedirect("insertedResponse.jsp?value="+executeUpdate);
			}else{
				response.sendRedirect("insertedResponse.jsp?value="+executeUpdate);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
