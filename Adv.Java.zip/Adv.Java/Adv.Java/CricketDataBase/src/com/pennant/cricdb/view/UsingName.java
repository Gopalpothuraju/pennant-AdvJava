package com.pennant.cricdb.view;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class UsingName
 */
@WebServlet("/UsingName")
public class UsingName extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("playerName");
		try {
			Statement createStatement = con.createStatement();
			ResultSet executeQuery = createStatement.executeQuery("select * from cricketer where name = '"+name+"'");
		
			if(executeQuery.next()){
			request.setAttribute("list", executeQuery);
			request.getRequestDispatcher("displaybyName.jsp").forward(request, response);
			}else{
				response.sendRedirect("home.html");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
