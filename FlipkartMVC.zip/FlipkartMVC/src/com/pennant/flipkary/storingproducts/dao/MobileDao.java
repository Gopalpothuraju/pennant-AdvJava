package com.pennant.flipkary.storingproducts.dao;

public class MobileDao {

}
