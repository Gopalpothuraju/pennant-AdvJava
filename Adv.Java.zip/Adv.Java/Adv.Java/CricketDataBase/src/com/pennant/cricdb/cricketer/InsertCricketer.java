package com.pennant.cricdb.cricketer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;


@WebServlet("/InsertCricketer")
public class InsertCricketer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
	Random r=new Random();

	static int executeUpdate=0;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	
	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String playerName = request.getParameter("playerName");
		int playerAge = Integer.parseInt(request.getParameter("playerAge"));
		String criketerType = request.getParameter("criketerType");
		String country = request.getParameter("country");
		int score = Integer.parseInt(request.getParameter("score"));
		int runs =  Integer.parseInt(request.getParameter("runs"));
		int matches =  Integer.parseInt(request.getParameter("matches"));
		int wickets =  Integer.parseInt(request.getParameter("wickets"));
		int totalWickets =  Integer.parseInt(request.getParameter("totalWickets"));
		double strikeRate=123.22;
		double economy=9.23;
		String sql="insert into cricketer values(?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement statement = con.prepareStatement(sql);
			statement.setString(1, playerName);
			statement.setInt(2, playerAge);
			statement.setString(3, criketerType);
			statement.setString(4, country);
			statement.setInt(5, score);
			statement.setInt(6, runs);
			statement.setInt(7, matches);
			statement.setInt(8, totalWickets);
			statement.setInt(9, wickets);
			statement.setDouble(10, strikeRate);
			statement.setDouble(11, economy);
			 executeUpdate = statement.executeUpdate();
				response.sendRedirect("insertedResponse.jsp?value="+executeUpdate);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
