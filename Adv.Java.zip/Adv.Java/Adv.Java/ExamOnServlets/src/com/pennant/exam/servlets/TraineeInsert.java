package com.pennant.exam.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TraineeInsert
 */
@WebServlet("/TraineeInsert")
public class TraineeInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
 	public void init(ServletConfig config) throws ServletException {
	con=DBConnection.getConnectToDb();
	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String specialization = request.getParameter("specialization");
		String gender = request.getParameter("gndr");
		String mobile = request.getParameter("mobile");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		try {
			PreparedStatement pst = con.prepareStatement("insert into traine values(?,?,?,?,?,?,?,?)");
			pst.setInt(1, id);
			pst.setString(2,firstName);
			pst.setString(3,lastName);
			pst.setString(4,specialization);
			pst.setString(5,gender);
			pst.setString(6,mobile);
			pst.setString(7,email);
			pst.setString(8,address);
			int i = pst.executeUpdate();
			if(i>0){
				response.sendRedirect("homePage.jsp");
			}
			else{
				response.sendRedirect("insertTrainee.html");
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}

}
