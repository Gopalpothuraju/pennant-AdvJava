package com.pennant.ems.view;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.ems.connection.DBConnection;

@WebServlet(name = "DisplayPhotoServlet", urlPatterns = {"/displayphoto"})
public class DisplayPhotoServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
Connection con=null;
@Override
public void init() throws ServletException {
	// TODO Auto-generated method stub
	con = DBConnection.getConnectToDb();
}
@Override
public void destroy() {
	// TODO Auto-generated method stub
try {
	con.close();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
}
	@Override 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
       
            PreparedStatement ps = con.prepareStatement("select EMP_PROFILE_IMAGE from EMPLOYEE_MANAGEMENT_SYSTEM where emp_id = ?");
            int id = Integer.parseInt(request.getParameter("emp_id"));
            ps.setInt(1,id );
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
            Blob b = rs.getBlob("EMP_PROFILE_IMAGE");
            response.setContentType("image/jpeg");
            response.setContentLength((int) b.length());
            InputStream is = b.getBinaryStream();
            OutputStream os = response.getOutputStream();
            byte buf[] = new byte[(int) b.length()];
            is.read(buf);
            os.write(buf);
            os.close();
            }
        } catch (Exception ex) {
        	ex.printStackTrace();
        }
    }

}