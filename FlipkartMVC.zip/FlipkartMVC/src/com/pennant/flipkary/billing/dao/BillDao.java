package com.pennant.flipkary.billing.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pennant.mvc.factory.DBConnection;

public class BillDao {
	Connection con = null;
	Statement st = null;
	ResultSet cust_Details = null;

	public BillDao() {
		con = DBConnection.getConnectToDb();
	}

	public ResultSet customerDetails(String userName) {
		try {
			cust_Details = st.executeQuery("select * from FLIPKART_CUSTOMERS where USERNAME='" + userName + "'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cust_Details;
	}

	public ResultSet billing(String products, String userName) {

		ResultSet prod_Details = null;
		try {
			st = con.createStatement();

			if (cust_Details.next()) {
				if (userName.equals(products)) {
					return null;
				} else {
					String sql = "select * from FLIPKART_PRODUCTS where PRODUCT_ID=?";

					PreparedStatement pst = con.prepareStatement(sql);
					pst.setInt(1, Integer.parseInt(products));
					prod_Details = pst.executeQuery();

				}

			}

		} catch (

		SQLException e) {
			e.printStackTrace();
		}
		return prod_Details;
	}
}
