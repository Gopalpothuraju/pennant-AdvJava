package com.pennant.mvc.bean;

public class FlipkartBilling {

		private int customerId;
		private int productId;
		
		public FlipkartBilling() {
			super();
		}
		public FlipkartBilling(int customerId, int productId) {
			super();
			this.customerId = customerId;
			this.productId = productId;
		}
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		@Override
		public String toString() {
			return "FlipkartBilling [customerId=" + customerId + ", productId=" + productId + "]";
		}
		
}
