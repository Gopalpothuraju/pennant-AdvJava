package com.pennant.cricdb.cricketer;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.cricdb.connection.DBConnection;

/**
 * Servlet implementation class MatchUpdate
 */
@WebServlet("/MatchUpdate")
public class MatchUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con = null;

	public void init(ServletConfig config) throws ServletException {
		con = DBConnection.getConnectToDb();
	}

	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String name = request.getParameter("playerName");
		int score = Integer.parseInt(request.getParameter("score"));
		int wickets = Integer.parseInt(request.getParameter("wickets"));
		int runs = score;
		int bowled = wickets;
		int i=0;
		try {
			Statement createStatement = con.createStatement();
			ResultSet rs = createStatement.executeQuery("select * from cricketer where name='" + name + "'");
			if (rs.next()) {
				if (score < rs.getInt("BESTSCOREINODI")) {
					score = rs.getInt("BESTSCOREINODI");
				}
				if (wickets < rs.getInt("TOPWICKETS")) {
					wickets = rs.getInt("TOPWICKETS");
				}
				String query = "update cricketer set bestscoreinodi=" + score + ", totalrunsinodi="
						+ (rs.getInt("TOTALRUNSINODI") + runs) + ",numberofmatches="
						+ (rs.getInt("NUMBEROFMATCHES") + 1) + ",TOTALWICKETS=" + (rs.getInt("TOTALWICKETS") + bowled)
						+ ",TOPWICKETS=" + wickets;
				 i = createStatement.executeUpdate(query);
				 response.sendRedirect("insertedResponse.jsp?value="+i);
				
			}
			else{
				 response.sendRedirect("insertedResponse.jsp?value="+i);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
