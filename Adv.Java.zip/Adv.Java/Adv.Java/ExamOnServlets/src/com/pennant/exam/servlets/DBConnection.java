package com.pennant.exam.servlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	static Connection con = null;
	static {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.27:1521:orcl", "DB344", "pass123");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public static Connection getConnectToDb() {
		return con;
	}
	public static void main(String[] args) {
		Connection toDb = getConnectToDb();
		System.out.println(toDb);
	}
}
