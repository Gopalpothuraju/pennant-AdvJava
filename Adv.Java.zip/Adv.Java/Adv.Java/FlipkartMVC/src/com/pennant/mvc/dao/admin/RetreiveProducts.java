package com.pennant.mvc.dao.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.pennant.mvc.factory.DBConnection;

public class RetreiveProducts {
	Connection con = null;

	public RetreiveProducts() {
		con = DBConnection.getConnectToDb();
	}

	public ResultSet retreiveProducts(String productType) {
		ResultSet rst=null;
		try {
			PreparedStatement pst = con
					.prepareStatement("select CATEGORY_ID from FLIPKART_CATAGORY where CATEGORY_NAME=?");
			pst.setString(1, productType);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				Statement st = con.createStatement();
				rst = st.executeQuery("select * from flipkart_products where CATEGORY_ID=" + rs.getInt(1));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rst;
	}
}
