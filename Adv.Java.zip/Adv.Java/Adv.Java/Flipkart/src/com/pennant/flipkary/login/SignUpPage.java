package com.pennant.flipkary.login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pennant.flipkary.connection.DBConnection;


@WebServlet("/SignUpPage")
public class SignUpPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	
	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName = request.getParameter("fname");
		String lastName = request.getParameter("lname");
		String email = request.getParameter("email");
		long mobile = Long.parseLong(request.getParameter("number"));
		String password = request.getParameter("pwd");
		
		
		String userName=firstName+lastName.charAt(0);
		
		try {
			PreparedStatement statement = con.prepareStatement("insert into flipkart_customers values(flipkart_customeres.nextval,?,?,?,?)");
			statement.setString(1,userName);
			statement.setString(2, password);
			statement.setString(3, email);
			
			statement.setLong(4, mobile);
			int i = statement.executeUpdate();
			if(i>0){
				response.sendRedirect("login.jsp");
			}else{
				response.sendRedirect("index.jsp");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
